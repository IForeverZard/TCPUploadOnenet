#ifndef __USART2_H
#define __USART2_H

void Usart2_Init(unsigned int baud);
void itoaTest(int num,unsigned char str[]);
void Usart2_SendString(unsigned char *str, unsigned short len);

#endif


