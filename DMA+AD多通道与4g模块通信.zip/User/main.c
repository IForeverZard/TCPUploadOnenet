#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "AD.h"
#include "usart1.h"
#include "usart2.h"

unsigned char admin[]="*579976#dev1#zard*";
unsigned char data[4];
uint8_t wendu;
uint8_t humi;
uint16_t idata;
int main(void)
{
	OLED_Init();
	AD_Init();
	Usart1_Init(115200);
	Usart2_Init(115200);
	Delay_ms(5000);
	OLED_ShowString(1, 1, "AD0:");
	OLED_ShowString(2, 1, "AD1:");
	OLED_ShowString(3, 1, "AD3:");
	OLED_ShowString(4, 1, "AD4:");
	Delay_ms(1000);
	Usart2_SendString(admin, 18);
	printf("��¼�����ѷ���");
	Delay_ms(1000);
	while (1)
	{
		OLED_ShowNum(1, 5, AD_Value[0], 4);
		OLED_ShowNum(2, 5, AD_Value[1], 4);
		wendu=AD_Value[0]/100;
		humi=AD_Value[1]/100;
		Delay_ms(50);
		OLED_ShowNum(3, 5, wendu, 2);
		OLED_ShowNum(4, 5, humi, 2);
		idata=(wendu*100)+humi;
		itoaTest(idata,data);
		Delay_ms(1000);
		Usart2_SendString(data, 4);
		printf("�¶������ѷ���");		
		Delay_ms(5000);
	}
}
